# In this tutorial, we will see how to model time series in R and, then,
# how we can make predictions of future time series data.

# We will make use of this package (install it if not present)
library(forecast)



# Load a simple time series database, already built-in in R
# The classic Box & Jenkins airline data.
# It records monthly totals of international airline passengers, from 1949 to 1960.

data(AirPassengers)

class(AirPassengers)
frequency(AirPassengers)
# So, this dataset in R is stored as a ts object of frequency 12

# Let us now see what we have loaded
AirPassengers
# it is a matrix (row=years, columns=months)

start(AirPassengers)
# data begins on January 1949

end(AirPassengers)
# data ends on December 1960

length(AirPassengers)
# 144 values, so 1 value per month, since we are considering 12 years

summary(AirPassengers)
# There seems to be quite some variability in the data


# Let us now plot the data

plot(AirPassengers)
# As we can see, the time series has a clear upward trend
# Moreover, it shows seasonality effects: winter months have typically less passengers than summer ones
# In addition, also observe that variability is increasing with time
# So, this time series is clearly not stationary

# The trend can also be highlighted by fitting a straigth line into our plot
abline(reg=lm(AirPassengers~time(AirPassengers)), col='red')

# We can get confirmation about our thoughts about winter and summer months 
# passenger traffic aggregating the data by month, and making some boxplots.
# Indeed, summer months have more passenger traffic
boxplot(AirPassengers~cycle(AirPassengers))

# As you can see here, for each data point in the time series,
# function cycle tells you the position of that particular data point in that cycle
print(cycle(AirPassengers))

# Let us try to decompose the series into trend, seasonality and residual
# As we have seen, since in this case the seasonality effects depend on time,
# we have to rely on a multiplicative model to do that
decomposeAirPassengers <- decompose(AirPassengers, "multiplicative")
autoplot(decomposeAirPassengers)


# Now, let us make some forecasts!

# The first step is making the time series stationary.
# Differencing is a classical operation by which we can do that.
# Differencing can help stabilize the mean of the time series by removing changes in the level
# of a time series, and so eliminating (or reducing) trend and seasonality effects.
# Differencing is performed by subtracting the previous observation from the current observation.

differenced <- diff(AirPassengers, differences= 1)
plot(differenced, type="l", main="Differenced and Stationary")
# Uh oh, the result is clearly not stationary... what happened here?

# Well, in our case, since the time series appears to be seasonal, a better approach is to subtract
# from each value of the time series the value that was observed in the same season one year earlier.

# Let's try that: apply seasonal differencing
AirPassengers_seasdiff <- diff(AirPassengers, lag=frequency(AirPassengers), differences=1) 
plot(AirPassengers_seasdiff, type="l", main="Seasonally Differenced")
# Uhm, better... but the time series is still not stationary, there is a clear trend here...

# Let us now apply classical differencing on the seasonally differenced time series
stationaryTS <- diff(AirPassengers_seasdiff, differences= 1)
plot(stationaryTS, type="l", main="Differenced and Stationary")
# Now, this is stationary!


# In order to train our forecasting models and evaluate them,
# we now subset train and test data using the window() function 
train_data = window(stationaryTS, end = c(1957,12))
test_data = window(stationaryTS, start = c(1958,1))

# First of all, let us try the naive method, that just copies the last value
# of the time series (there also exists snaive, which copies the corresponding seasonal
# value from the previous season, but we do not need it here, having a stationary time series)
naive_method_forecast = naive(train_data, h=36, level = c(80, 95))
plot(naive_method_forecast)
lines(test_data, col='red')
summary(naive_method_forecast)

# Results are not exceptional (around 15 training set RMSE), however naive is useful to establish a baseline result
# In the plot, we can also see the 80% and 95% confidence intervals, respecively in darker and lighter blue color


# Now, we may use a more complex technique, Simple Exponential Smoothing
# Simple exponential smoothing assumes that the time series data has only a level and some error (also known as remainder)
# but no trend or seasonality, which is the case of our stationary time series data.
# In exponential smoothing, all past observations are part of the calculation for the forecasted value.
# The smoothing parameter ALPHA determines the distribution of weights of past observations and, with that,
# how heavily a given time period is factored into the forecasted value.
# If the smoothing parameter is close to 1, recent observations carry more weight;
# otherwise, if the smoothing parameter is closer to 0, weights of older and recent observations are more balanced.
ses_method_forecast = ses(train_data, h=36, level = c(80, 95))
plot(ses_method_forecast)
lines(test_data, col='red')
summary(ses_method_forecast)

# This is a little bit better, with a training set RMSE of around 10
# As you can see, SES just projects a flatlined estimate into the future.
# This is the reason why it should not be used on data with a trend or seasonal component
# However, there are some variants of Exponential Smoothing that can handle that (see bottom of the tutorial)...


# Finally, we apply ARIMA
# ARIMA stands for Auto Regressive Integrated Moving Average, which indicates that an ARIMA model has three components, i.e.:
# - Auto-Regressive: past time series points may impact its current and future values. Thus, ARIMA uses p past observations
#                    to forecast current and future values. Auto-regression is employed, that is, the process of applying
#                    regression on a variable considering past values of itself. In other words, the current value of the series
#                    is determined as a linear combination of p past values (which may also be previous forecasts).
# - Integrated: the forecasting method cannot be applied to non-stationary time series. Thus, differencing is applied to 
#               reduce trend and seasonality effects.
# - Moving Average: also past noise in the series might influence its current and future values. For instance, a "shock" in a 
#                   stock market time series will persist in a smaller extent in the next days as well. Thus, rather than
#                   using the past values of the forecast, the moving average model uses past forecast errors in a
#                   regression-like fashion. Specifically, the result is a weighted moving average over past forecast errors.
#
# The R function to call ARIMA is (unsurprisingly) named "arima", and features three parameters:
# p: number of lag values to consider in the auto-regressive part  (e.g., p=3 means we will use the 3 previous values of
#    our time series in the autoregressive portion of the calculation)
# d: number of differencing transformations applied to the time series to make it stationary (from previous experiments,
#    we already know we need 1 seasonal differencing and 1 "plain" differencing)
# q: the size of the moving average window
# The parameter "order" encodes the three previously mentioned components (p, d, q) 
# For seasonal ARIMA, parameter "seasonal" encodes the three components (p, d, q) for the seasonal part, plus the length
# of the period (12 months in our case)
#
# The interested reader may find further details regarding ARIMA for instance here:
# http://people.cs.pitt.edu/~milos/courses/cs3750/lectures/class16.pdf



# We start from the original time series data, since the differencing is applied within ARIMA
train_data_arima = window(AirPassengers, end = c(1957,12))
test_data_arima = window(AirPassengers, start = c(1958,1))

arima_model <- arima(train_data_arima, order=c(2, 1, 0), seasonal=list(order=c(2, 1, 0), period = 12))
arima_forecast = forecast(arima_model, n=36, level = c(80, 95))
plot(arima_forecast)
lines(test_data_arima, col='red')
summary(arima_model)

# It does much better than previous - quite naive - methods!



# Ok, now, for instance, you can refer to this webpage and try other, more complex, variants of Exponential Smoothing!
# http://uc-r.github.io/ts_exp_smoothing 
# Also, you may try to apply the naive and Simple Eponential Smoothing methods on the original, non-stationary time series
# Or, just play around with ARIMA parameters: can yoyu get a better fit?

